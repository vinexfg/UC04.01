export let alunos = [
  {
    id: 1,
    nome: "Vinicius",
    idade: "21",
    curso: "ADS",
    matricula: "123256"
  },
  {
    id: 2,
    nome: "Vini",
    idade: "23",
    curso: "ADS",
    matricula: "567432"
  }
];